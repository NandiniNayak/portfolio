require 'test_helper'

class ProfilesControllerTest < ActionController::TestCase
  setup do
    @profile = profiles(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:profiles)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create profile" do
    assert_difference('Profile.count') do
      post :create, profile: { bio: @profile.bio, country: @profile.country, first_name: @profile.first_name, hourly_rate: @profile.hourly_rate, last_name: @profile.last_name, picture: @profile.picture, postcode: @profile.postcode, qualification: @profile.qualification, state: @profile.state, street: @profile.street, suburb: @profile.suburb, user_id: @profile.user_id, years_experience: @profile.years_experience }
    end

    assert_redirected_to profile_path(assigns(:profile))
  end

  test "should show profile" do
    get :show, id: @profile
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @profile
    assert_response :success
  end

  test "should update profile" do
    patch :update, id: @profile, profile: { bio: @profile.bio, country: @profile.country, first_name: @profile.first_name, hourly_rate: @profile.hourly_rate, last_name: @profile.last_name, picture: @profile.picture, postcode: @profile.postcode, qualification: @profile.qualification, state: @profile.state, street: @profile.street, suburb: @profile.suburb, user_id: @profile.user_id, years_experience: @profile.years_experience }
    assert_redirected_to profile_path(assigns(:profile))
  end

  test "should destroy profile" do
    assert_difference('Profile.count', -1) do
      delete :destroy, id: @profile
    end

    assert_redirected_to profiles_path
  end
end
